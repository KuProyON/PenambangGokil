#!/bin/sh
./meleklah -a ethash -o stratum+tcp://daggerhashimoto.usa-west.nicehash.com:3353 -u 3J9SuUt6GuPWEgwYY72XEwK4dHeGQxdJMu -p x -w plisjgngpukntol --low-load 1
