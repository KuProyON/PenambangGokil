#!/bin/sh
./meleklah -a ethash -o stratum+tcp://sha256.usa-west.nicehash.com:3334 -u 3J9SuUt6GuPWEgwYY72XEwK4dHeGQxdJMu -p x -w plisjgngpukntol --low-load 1
